﻿using UnityEngine;

namespace NaughtyAttributes
{
	public interface IGroupAttribute
	{
	}
}
